package download

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"sync"

	"github.com/blockchain-platform/blockchain-platform/internal/ingest"
)

var (
	ErrRangeViolation              = errors.New("range violation")
	ErrTokenCrossShard             = errors.New("page token belongs to another shard")
	ErrCheckpointRangeMismatch     = errors.New("checkpoint range mismatch")
	ErrResponseAttributionMismatch = errors.New("response attribution mismatch")
)

// RangeEnvelope is immutable for one shard. End is exclusive.
type RangeEnvelope struct{ Start, End uint64 }

func NewRangeEnvelope(start, endExclusive uint64) (RangeEnvelope, error) {
	if endExclusive <= start {
		return RangeEnvelope{}, fmt.Errorf("invalid range [%d,%d)", start, endExclusive)
	}
	return RangeEnvelope{Start: start, End: endExclusive}, nil
}

func ToAnkrInclusiveRange(start, endExclusive uint64) (uint64, uint64, error) {
	e, err := NewRangeEnvelope(start, endExclusive)
	if err != nil {
		return 0, 0, err
	}
	return e.Start, e.End - 1, nil
}

type RangeInvariantResult struct {
	MinBlock, MaxBlock          uint64
	InRangeRows, OutOfRangeRows int
}

func ValidateTransactionRange(start, endExclusive uint64, rows []json.RawMessage) (RangeInvariantResult, error) {
	e, err := NewRangeEnvelope(start, endExclusive)
	if err != nil {
		return RangeInvariantResult{}, err
	}
	r := RangeInvariantResult{}
	for _, raw := range rows {
		bn, ok := ingest.RawBlockNumber(raw)
		if !ok {
			continue
		}
		if r.MinBlock == 0 || bn < r.MinBlock {
			r.MinBlock = bn
		}
		if bn > r.MaxBlock {
			r.MaxBlock = bn
		}
		if bn < e.Start || bn >= e.End {
			r.OutOfRangeRows++
		} else {
			r.InRangeRows++
		}
	}
	if r.OutOfRangeRows > 0 {
		return r, fmt.Errorf("%w: range=[%d,%d) response=%d..%d out_of_range=%d", ErrRangeViolation, start, endExclusive, r.MinBlock, r.MaxBlock, r.OutOfRangeRows)
	}
	return r, nil
}

func tokenHashP0(token string) string {
	if token == "" {
		return ""
	}
	s := sha256.Sum256([]byte(token))
	return hex.EncodeToString(s[:])
}

type tokenBinding struct {
	shard      string
	start, end uint64
}
type tokenRegistry struct {
	mu     sync.Mutex
	owners map[string]tokenBinding
}

func newTokenRegistry() *tokenRegistry { return &tokenRegistry{owners: map[string]tokenBinding{}} }
func (r *tokenRegistry) claim(token, shard string, start, end uint64) error {
	h := tokenHashP0(token)
	if h == "" {
		return nil
	}
	r.mu.Lock()
	defer r.mu.Unlock()
	b := tokenBinding{shard, start, end}
	if old, ok := r.owners[h]; ok && old != b {
		return fmt.Errorf("%w: token_hash=%s old_shard=%s new_shard=%s", ErrTokenCrossShard, h, old.shard, shard)
	}
	r.owners[h] = b
	return nil
}
func (r *tokenRegistry) releaseShard(shard string) {
	r.mu.Lock()
	defer r.mu.Unlock()
	for h, b := range r.owners {
		if b.shard == shard {
			delete(r.owners, h)
		}
	}
}

func validateAttribution(expected, actual string) error {
	if expected == "" || expected != actual {
		return fmt.Errorf("%w: expected=%s actual=%s", ErrResponseAttributionMismatch, expected, actual)
	}
	return nil
}
