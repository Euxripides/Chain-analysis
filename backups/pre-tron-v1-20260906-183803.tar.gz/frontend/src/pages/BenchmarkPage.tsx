import { useEffect, useMemo, useState } from 'react'
import { Gauge, Play, RefreshCw } from 'lucide-react'
import { api } from '../api/client'
import NoticeDialog from '../components/NoticeDialog'
import { type BenchmarkRun } from '../types'
import { datasetLabel } from '../utils/field-labels'

const fmtWall = (ms: number) => ms >= 60000 ? (ms / 60000).toFixed(1) + 'm' : (ms / 1000).toFixed(1) + 's'
const fmtRows = (n: number) => n >= 1000 ? (n / 1000).toFixed(1) + 'K' : String(n)

export default function BenchmarkPage() {
  const [runs, setRuns] = useState<BenchmarkRun[]>([])
  const [busy, setBusy] = useState(false)
  const [notice, setNotice] = useState('')
  const [chain, setChain] = useState('bsc')
  const [dataset, setDataset] = useState('token_transfers')
  const [address, setAddress] = useState('')
  const [targetBlock, setTargetBlock] = useState('')
  const [shardCount, setShardCount] = useState(4)

  async function load() {
    try { setRuns((await api.listBenchmarks(chain, dataset, 100)).benchmarks ?? []) } catch { /* keep last */ }
  }
  useEffect(() => { void load(); const t = window.setInterval(() => void load(), 5000); return () => window.clearInterval(t) }, [chain, dataset])

  async function create() {
    setBusy(true); setNotice('')
    try {
      const res = await api.createBenchmark({
        chain, dataset, address: address.trim().toLowerCase(),
        target_block: Number(targetBlock), shard_count: shardCount, page_size: 10000,
      })
      setNotice('Benchmark 已启动：job ' + res.job_id.slice(0, 8) + '（' + shardCount + ' Range，固定 target ' + Number(targetBlock).toLocaleString() + '）')
      void load()
    } catch (e) { setNotice(e instanceof Error ? e.message : String(e)) }
    finally { setBusy(false) }
  }

  // §47 Compare UI：按 address_hash + target_block 分组；组内 PASS 且墙钟最小（10% 内最小 shard）→ RECOMMENDED
  const groups = useMemo(() => {
    const map = new Map<string, BenchmarkRun[]>()
    for (const r of runs ?? []) {
      const key = r.address_hash + '@' + r.target_block
      map.set(key, [...(map.get(key) ?? []), r])
    }
    const out: { key: string; rows: BenchmarkRun[]; best: number }[] = []
    for (const [key, rows] of map) {
      const pass = rows.filter((r) => r.integrity_status === 'PASS' && r.status === 'COMPLETED')
      let best = Number.MAX_SAFE_INTEGER
      if (pass.length) {
        const minWall = Math.min(...pass.map((r) => r.wall_clock_ms))
        for (const r of pass) if (r.wall_clock_ms <= minWall * 1.1 && r.shard_count < best) best = r.shard_count
      }
      out.push({ key, rows: rows.sort((a, b) => a.shard_count - b.shard_count), best })
    }
    return out
  }, [runs])

  return <div className="workspace-page benchmark-page">
    <header className="page-header"><div><h1>极限性能 Benchmark</h1><p>固定 target_block 的 1/2/4/8 Range 对比（V1.1 §8-§13）</p></div></header>

    <section className="benchmark-form panel">
      <div className="benchmark-form-row">
        <label>链<input value={chain} onChange={(e) => setChain(e.target.value)} list="bench-chains" /></label>
        <datalist id="bench-chains"><option value="bsc" /><option value="eth" /><option value="polygon" /></datalist>
        <label>Dataset<select value={dataset} onChange={(e) => setDataset(e.target.value)}><option value="token_transfers">Token Transfers</option><option value="logs">Logs</option></select></label>
        <label>地址<input value={address} onChange={(e) => setAddress(e.target.value)} placeholder="0x…" /></label>
        <label>Target Block<input type="number" value={targetBlock} onChange={(e) => setTargetBlock(e.target.value)} placeholder="119720000" /></label>
        <label>Shard Count<select value={shardCount} onChange={(e) => setShardCount(Number(e.target.value))}>{[0, 1, 2, 4, 8].map((n) => <option key={n} value={n}>{n === 0 ? 'Adaptive（学习值）' : n + ' Range'}</option>)}</select></label>
        <button className="primary-button" disabled={busy || !address.trim() || !Number(targetBlock)} onClick={() => void create()}><Play size={15} />{busy ? '启动中…' : '运行'}</button>
        <button className="icon-button" title="刷新" onClick={() => void load()}><RefreshCw size={16} /></button>
      </div>
    </section>

    {groups.map((g) => <section className="benchmark-group panel" key={g.key}>
      <header className="benchmark-group-head"><h2>地址 {g.key.split('@')[0]} <span className="mono">target={Number(g.key.split('@')[1]).toLocaleString()}</span></h2><Gauge size={16} /></header>
      <div className="task-table-scroll"><table className="task-table">
        <thead><tr><th>Shards</th><th>状态</th><th>Wall Clock</th><th>Norm. Wall（§53）</th><th>Provider P50 / TTFB（§55）</th><th>请求</th><th>Credits</th><th>P50/P95</th><th>Retry</th><th>Rows</th><th>Unique</th><th>429/超时</th><th>重叠/缺口</th><th>完整性</th><th>推荐</th></tr></thead>
        <tbody>{g.rows.map((r) => <tr key={r.id} className={r.integrity_status === 'FAIL' ? 'failed' : ''}>
          <td>{r.shard_count}</td>
          <td>{r.status === 'RUNNING' ? <span className="status-badge status-running"><i />运行中</span> : r.status === 'COMPLETED' ? '完成' : '失败'}</td>
          <td>{r.wall_clock_ms > 0 ? fmtWall(r.wall_clock_ms) : '—'}</td>
          <td title={(r.normalized_wall_clock_ms ?? 0) > 0 ? '归一化墙钟 = wall / provider_latency_baseline_ratio（§53）' : 'Provider 延迟归一化关闭或基线缺失'}>{(r.normalized_wall_clock_ms ?? 0) > 0 ? fmtWall(r.normalized_wall_clock_ms as number) : '—'}</td>
          <td title={'Provider P50=' + (r.provider_latency_p50_ms || 0) + 'ms P95=' + (r.provider_latency_p95_ms || 0) + 'ms · TTFB P50=' + (r.provider_ttfb_p50_ms || 0) + 'ms · Body P50=' + (r.provider_body_p50_ms || 0) + 'ms'}>{r.provider_latency_p50_ms ? r.provider_latency_p50_ms + ' / ' + (r.provider_ttfb_p50_ms || '—') + 'ms' : '—'}</td>
          <td>{r.requests}</td>
          <td>{Number(r.credits || 0).toLocaleString()}</td>
          <td>{r.p50_ms}ms / {r.p95_ms}ms</td>
          <td>{(r.retry_rate * 100).toFixed(0)}%</td>
          <td>{fmtRows(r.rows)}</td>
          <td>{fmtRows(r.unique_rows)}</td>
          <td>{r.error_429}/{r.error_timeout}</td>
          <td>{r.raw_overlap_rows}/{r.boundary_missing}</td>
          <td><span title={r.exclude_reason || (r.excluded_from_learning ? 'excluded_from_learning' : '')} className={r.integrity_status === 'PASS' ? 'success-text' : r.integrity_status === 'FAIL' ? 'error-text' : ''}>{r.integrity_status}{r.excluded_from_learning ? ' · 排除' : ''}</span></td>
          <td>{g.best === r.shard_count && r.integrity_status === 'PASS' ? <span className="status-badge status-completed"><i />RECOMMENDED</span> : ''}</td>
        </tr>)}</tbody>
      </table></div>
      {g.rows.some((r) => r.boundary_evidence?.ranges?.length) && <details className="boundary-evidence"><summary>Boundary Evidence（无漏无重证据，§16）</summary><div className="task-table-scroll"><table className="task-table"><thead><tr><th>Shards</th><th>Range</th><th>First/Last Block</th><th>Rows</th><th>Pages</th><th>首尾 Tx</th></tr></thead><tbody>{g.rows.flatMap((r) => (r.boundary_evidence?.ranges ?? []).map((rg, i) => <tr key={r.id + i}><td>{r.shard_count}</td><td className="mono">{rg.range_start.toLocaleString()} → {rg.range_end.toLocaleString()}</td><td className="mono">{rg.first_block?.toLocaleString() ?? '—'} / {rg.last_block?.toLocaleString() ?? '—'}</td><td>{rg.rows.toLocaleString()}</td><td>{rg.pages}</td><td className="mono">{(rg.first_tx_hash ?? '—').slice(0, 10)}… / {(rg.last_tx_hash ?? '—').slice(0, 10)}…</td></tr>))}</tbody></table></div></details>}
    </section>)}

    {!groups.length && <div className="table-empty"><Gauge size={20} /><b>暂无 Benchmark 记录</b><span>填写左侧表单并运行 1/2/4/8 Range 对比</span></div>}

    {notice && <NoticeDialog title="Benchmark" message={notice} onClose={() => setNotice('')} />}
  </div>
}