# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: r9-uc-download-import-v2.spec.ts >> R9 U-DL-01 CSV/XLSX import (app-v2) >> R9-02 坏文件：解析失败必须走 Dialog，且不得发出任何校验/创建请求
- Location: tests/r9-uc-download-import-v2.spec.ts:164:3

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('[role="dialog"]').filter({ hasText: '文件解析失败' })
Expected: visible
Timeout: 30000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 30000ms
  - waiting for locator('[role="dialog"]').filter({ hasText: '文件解析失败' })

```

```yaml
- navigation "主导航":
  - text: ChainSight 调查工作台 · user 工作台
  - link "我的概览":
    - /url: /app-v2/home
    - img
    - text: 我的概览
  - link "全局搜索":
    - /url: /app-v2/search
    - img
    - text: 全局搜索
  - text: 案件与调查
  - link "案件中心":
    - /url: /app-v2/cases
    - img
    - text: 案件中心
  - link "调查任务":
    - /url: /app-v2/investigations
    - img
    - text: 调查任务
  - link "资金图谱":
    - /url: /app-v2/graph
    - img
    - text: 资金图谱
  - text: 数据工具
  - link "地址与交易查询":
    - /url: /app-v2/explorer
    - img
    - text: 地址与交易查询
  - link "数据下载":
    - /url: /app-v2/downloads/new
    - img
    - text: 数据下载
  - link "任务中心":
    - /url: /app-v2/jobs
    - img
    - text: 任务中心
  - link "导出中心":
    - /url: /app-v2/exports
    - img
    - text: 导出中心
  - text: 协作
  - link "待我处理":
    - /url: /app-v2/inbox
    - img
    - text: 待我处理
  - link "报告中心":
    - /url: /app-v2/reports
    - img
    - text: 报告中心
  - link "通知":
    - /url: /app-v2/notifications
    - img
    - text: 通知
  - text: 个人
  - link "个人资料与安全":
    - /url: /app-v2/profile
    - img
    - text: 个人资料与安全
  - button "收起导航":
    - img
    - text: 收起导航
- banner:
  - button "打开主导航":
    - img
  - text: 用户层系统 S7 JobScope investigator investigator
  - button "退出":
    - img
    - text: 退出
- main:
  - heading "新建数据下载" [level=1]
  - button "任务中心"
  - heading "1 · 对象（地址）" [level=2]
  - text: 地址列表（已导入 0 个）
  - textbox "地址列表（已导入 0 个）":
    - /placeholder: 每行一个地址，或用逗号/分号/空白分隔后粘贴
  - button "解析导入"
  - button "导入 CSV / XLSX"
  - button "清空" [disabled]
  - heading "2 · 链与范围" [level=2]
  - text: 链
  - combobox "链":
    - option "请选择链"
    - option "Arbitrum One（arbitrum）" [selected]
    - option "Avalanche C-Chain（avalanche）"
    - option "Base（base）"
    - option "BNB Smart Chain（bsc）"
    - option "Ethereum（eth）"
    - option "OP Mainnet（optimism）"
    - option "Polygon PoS（polygon）"
    - option "TRON（tron）"
  - text: 范围类型
  - combobox "范围类型":
    - option "full · 全量" [selected]
    - option "block · 区块区间"
    - option "time · 时间区间"
  - text: 性能模式
  - combobox "性能模式":
    - option "safe" [selected]
    - option "fast"
    - option "turbo"
  - heading "3 · Dataset" [level=2]
  - group "Dataset 选择":
    - checkbox "普通交易（transactions）" [checked]
    - text: 普通交易（transactions）
    - checkbox "Token Transfer（token_transfers）" [checked]
    - text: Token Transfer（token_transfers）
    - checkbox "NFT Transfer（nft_transfers）"
    - text: NFT Transfer（nft_transfers）
    - checkbox "事件日志（logs）"
    - text: 事件日志（logs）
    - checkbox "地址余额快照（balances）"
    - text: 地址余额快照（balances）
    - checkbox "内部调用（internal_transactions）"
    - text: 内部调用（internal_transactions）
  - heading "4 · 复用策略" [level=2]
  - radiogroup "复用策略":
    - radio "prefer_local（默认，优先复用本地）" [checked]
    - text: prefer_local（默认，优先复用本地）
    - radio "refresh（不复用，新增 Provider 工作）"
    - text: refresh（不复用，新增 Provider 工作）
  - heading "5 · Coverage / 成本预览" [level=2]
  - button "预览 Coverage 与成本"
  - text: 尚未预览
  - button "立即预览"
  - button "取消"
  - button "创建下载任务"
  - complementary "预览来源与复用":
    - heading "预览来源与复用" [level=2]
    - text: 复用策略 prefer_local Coverage 命中 — 将复用 — 候选任务 — refresh — 估算依据 — Coverage 来源 — Provider 来源 — 数据时点 — 最近 Trace —
- dialog "地址导入解析摘要（浏览器）":
  - heading "地址导入解析摘要（浏览器）" [level=2]
  - button "关闭对话框":
    - img
  - text: 本地摘要只做拆分与计数；接受/拒绝与规范化地址以服务端再次验证为准。
  - term: 文件名
  - definition: bad.xlsx
  - term: 文件类型
  - definition: XLSX/Excel
  - term: 扫描行数
  - definition: "2"
  - term: 空白行
  - definition: "0"
  - term: 识别表头
  - definition: 无表头（整表当地址清单）
  - term: 可选列
  - definition: 无
  - term: 链分布（本地）
  - definition: arbitrum:2
  - term: 带案件/标签的行
  - definition: "0"
  - term: 本次送校验
  - definition: 2 个地址
  - button "取消"
  - button "提交服务端校验"
```

# Test source

```ts
  74  |   await page.locator("#password").fill(PASSWORD);
  75  |   await page.getByRole("button", { name: /^登录(后台)?$/ }).click();
  76  |   await expect.poll(() => page.url(), { timeout: 30_000 }).not.toContain(LOGIN_PATH);
  77  | }
  78  | 
  79  | async function openDownloadsNew(page: Page) {
  80  |   await page.goto("/app-v2/downloads/new", { waitUntil: "domcontentloaded" });
  81  |   await expect(page.locator("#download-addresses"), "address textarea").toBeVisible({ timeout: 30_000 });
  82  |   // 链与 Dataset 来自服务端 registry，等它们加载完成再操作。
  83  |   await expect.poll(async () => page.locator("#download-chain option").count(), { timeout: 30_000 }).toBeGreaterThan(1);
  84  | }
  85  | 
  86  | async function importFile(page: Page, file: string) {
  87  |   await page.locator('input[aria-label="导入地址文件"]').setInputFiles(file);
  88  | }
  89  | 
  90  | const dialog = (page: Page) => page.locator('[role="dialog"]');
  91  | 
  92  | test.describe("R9 U-DL-01 CSV/XLSX import (app-v2)", () => {
  93  |   test("R9-01 最小 .xlsx 导入：浏览器摘要 → 服务端再次验证 → 未解析案件/标签被移除 → 真实创建", async ({ page }, testInfo) => {
  94  |     test.skip(!EMAIL || !PASSWORD || !ADDRESS, "R9_EMAIL/R9_PASSWORD/R9_ADDRESS not provided");
  95  |     test.skip(testInfo.project.name !== "uc-desktop", "desktop-only assertion set");
  96  |     const net: NetRecord[] = [];
  97  |     startCapture(page, net);
  98  |     await login(page);
  99  |     await openDownloadsNew(page);
  100 |     await page.locator("#download-chain").selectOption(CHAIN);
  101 |     await importFile(page, path.join(FIX, "min.xlsx"));
  102 | 
  103 |     // 1) 浏览器解析摘要（本地）
  104 |     const localDialog = dialog(page).filter({ hasText: "地址导入解析摘要（浏览器）" });
  105 |     await expect(localDialog).toBeVisible({ timeout: 30_000 });
  106 |     const localText = await localDialog.innerText();
  107 |     expect(localText, "本地摘要必须报出 chain 列与案件/标签列被识别").toContain("chain");
  108 |     expect(localText, "本地摘要必须报出 case 列").toContain("case");
  109 |     expect(localText, "本地摘要必须报出 tags 列").toContain("tags");
  110 |     await page.getByRole("button", { name: "提交服务端校验" }).click();
  111 | 
  112 |     // 2) 服务端再次验证
  113 |     const serverDialog = dialog(page).filter({ hasText: "服务端地址校验结果" });
  114 |     await expect(serverDialog).toBeVisible({ timeout: 30_000 });
  115 |     const serverText = await serverDialog.innerText();
  116 |     expect(serverText, "服务端必须返回接受/拒绝计数").toContain("服务端接受");
  117 |     expect(serverText, "不存在的案件必须被明确标注为已移除，而不是只写不发生绑定").toContain("已从本次提交中移除");
  118 |     expect(serverText, "必须列出不存在的案件名").toContain(MISSING_CASE);
  119 |     expect(serverText, "必须列出不存在的标签名").toContain(MISSING_TAG);
  120 |     expect(serverText, "必须说明名称已从 payload 中移除").toContain("已从创建请求的 payload 中移除");
  121 |     await page.screenshot({ path: path.join(OUT, testInfo.project.name, "01-server-verdict.png"), fullPage: false });
  122 |     await page.getByRole("button", { name: "使用服务端结果" }).click();
  123 | 
  124 |     // 3) 预览（真实服务端 Coverage）
  125 |     await page.getByRole("button", { name: "Coverage 预览" }).click();
  126 |     const previewDialog = dialog(page).filter({ hasText: /无需新增 Provider 请求|Coverage 与成本预览完成|预览完成，存在风险提示/ });
  127 |     await expect(previewDialog).toBeVisible({ timeout: 60_000 });
  128 |     await page.screenshot({ path: path.join(OUT, testInfo.project.name, "02-preview.png"), fullPage: false });
  129 |     await previewDialog.getByRole("button", { name: "知道了" }).click();
  130 | 
  131 |     // 4) 真实创建
  132 |     await page.getByRole("button", { name: /创建下载任务|正在创建/ }).click();
  133 |     const confirmDialog = dialog(page).filter({ hasText: "确认创建下载任务？" });
  134 |     await expect(confirmDialog).toBeVisible({ timeout: 30_000 });
  135 |     await page.getByRole("button", { name: "确认创建" }).click();
  136 |     const resultDialog = dialog(page).filter({ hasText: /下载任务已创建|已复用现有任务|本地数据已覆盖|部分创建成功/ });
  137 |     await expect(resultDialog).toBeVisible({ timeout: 90_000 });
  138 |     const resultText = await resultDialog.innerText();
  139 |     await page.screenshot({ path: path.join(OUT, testInfo.project.name, "03-created.png"), fullPage: false });
  140 | 
  141 |     // 5) 断言真实请求体：只提交服务端 accepted 的 normalized 地址，且不带未解析元数据
  142 |     const previewCalls = net.filter((r) => r.url.includes("/api/v2/downloads/preview") && r.method === "POST");
  143 |     const createCalls = net.filter((r) => /\/api\/v2\/downloads$/.test(r.url) && r.method === "POST");
  144 |     expect(previewCalls.length, "必须真实调用过 preview").toBeGreaterThan(0);
  145 |     expect(createCalls.length, "必须真实调用过 create").toBe(1);
  146 |     const previewBody = JSON.parse(previewCalls[previewCalls.length - 1].requestBody ?? "{}");
  147 |     const createBody = JSON.parse(createCalls[0].requestBody ?? "{}");
  148 |     expect(previewBody.chain).toBe(CHAIN);
  149 |     expect(previewBody.addresses).toEqual([ADDRESS.toLowerCase()]);
  150 |     expect(Object.keys(previewBody.subject_meta ?? {}), "未解析的案件/标签不得出现在 payload 中").toEqual([]);
  151 |     expect(createBody.addresses).toEqual([ADDRESS.toLowerCase()]);
  152 |     expect(createBody.subject_meta ?? {}, "create 也不得携带未解析元数据").toEqual({});
  153 |     const createResponse = JSON.parse(createCalls[0].responseBody ?? "{}");
  154 |     dump(testInfo, "r9-01-evidence.json", {
  155 |       local_summary_text: localText, server_verdict_text: serverText, result_text: resultText,
  156 |       preview_request_body: previewBody, create_request_body: createBody, create_response: createResponse,
  157 |       preview_trace_ids: previewCalls.map((c) => ({ request_id: c.requestId, trace_id: c.traceId, status: c.status })),
  158 |       create_trace_ids: createCalls.map((c) => ({ request_id: c.requestId, trace_id: c.traceId, status: c.status })),
  159 |       all_api_calls: net.map((c) => ({ method: c.method, url: c.url, status: c.status, request_id: c.requestId, trace_id: c.traceId })),
  160 |     });
  161 |     expect(createCalls[0].status, "create 必须 200/201/202").toBeLessThan(300);
  162 |   });
  163 | 
  164 |   test("R9-02 坏文件：解析失败必须走 Dialog，且不得发出任何校验/创建请求", async ({ page }, testInfo) => {
  165 |     test.skip(!EMAIL || !PASSWORD || !ADDRESS, "creds not provided");
  166 |     test.skip(testInfo.project.name !== "uc-desktop", "desktop-only assertion set");
  167 |     const net: NetRecord[] = [];
  168 |     startCapture(page, net);
  169 |     await login(page);
  170 |     await openDownloadsNew(page);
  171 |     await importFile(page, path.join(FIX, "bad.xlsx"));
  172 | 
  173 |     const errDialog = dialog(page).filter({ hasText: "文件解析失败" });
> 174 |     await expect(errDialog).toBeVisible({ timeout: 30_000 });
      |                             ^ Error: expect(locator).toBeVisible() failed
  175 |     const text = await errDialog.innerText();
  176 |     expect(text).toContain("bad.xlsx");
  177 |     await page.screenshot({ path: path.join(OUT, testInfo.project.name, "04-bad-file.png"), fullPage: false });
  178 |     await errDialog.getByRole("button", { name: "知道了" }).click();
  179 | 
  180 |     const validateCalls = net.filter((r) => r.url.includes("validate-addresses"));
  181 |     const createCalls = net.filter((r) => r.url.includes("/api/v2/downloads"));
  182 |     dump(testInfo, "r9-02-evidence.json", { dialog_text: text, validate_calls: validateCalls.length, create_calls: createCalls.length, all_api_calls: net.map((c) => ({ method: c.method, url: c.url, status: c.status })) });
  183 |     expect(validateCalls.length, "坏文件不得触发服务端校验").toBe(0);
  184 |     expect(createCalls.length, "坏文件不得触发创建").toBe(0);
  185 |   });
  186 | 
  187 |   test("R9-03 大文件 150 行：上限必须显式报出（接受 100 / 拒绝 50），取消后不得预览", async ({ page }, testInfo) => {
  188 |     test.skip(!EMAIL || !PASSWORD || !ADDRESS, "creds not provided");
  189 |     test.skip(testInfo.project.name !== "uc-desktop", "desktop-only assertion set");
  190 |     const net: NetRecord[] = [];
  191 |     startCapture(page, net);
  192 |     await login(page);
  193 |     await openDownloadsNew(page);
  194 |     await page.locator("#download-chain").selectOption(CHAIN);
  195 |     await importFile(page, path.join(FIX, "large.xlsx"));
  196 | 
  197 |     const localDialog = dialog(page).filter({ hasText: "地址导入解析摘要（浏览器）" });
  198 |     await expect(localDialog).toBeVisible({ timeout: 30_000 });
  199 |     const localText = await localDialog.innerText();
  200 |     expect(localText, "本地摘要必须报出超上限行数").toContain("超出单次上限");
  201 |     await page.getByRole("button", { name: "提交服务端校验" }).click();
  202 | 
  203 |     const serverDialog = dialog(page).filter({ hasText: "服务端地址校验结果" });
  204 |     await expect(serverDialog).toBeVisible({ timeout: 60_000 });
  205 |     const serverText = await serverDialog.innerText();
  206 |     await page.screenshot({ path: path.join(OUT, testInfo.project.name, "05-large-file.png"), fullPage: false });
  207 |     const validateCall = net.filter((r) => r.url.includes("validate-addresses")).pop();
  208 |     const verdict = JSON.parse(validateCall?.responseBody ?? "{}");
  209 |     dump(testInfo, "r9-03-evidence.json", {
  210 |       local_summary_text: localText, server_verdict_text: serverText,
  211 |       server_summary: verdict.summary, cap_rejected_sample: (verdict.rejected ?? []).slice(0, 3),
  212 |     });
  213 |     expect(verdict.summary?.accepted, "服务端必须恰好接受 100 条").toBe(100);
  214 |     expect(verdict.summary?.cap_rejected, "服务端必须显式拒绝其余 50 条").toBe(50);
  215 |     expect(serverText, "Dialog 必须显示被拒 50 条").toContain("服务端拒绝");
  216 |     await page.getByRole("button", { name: "取消" }).click();
  217 |     await expect(serverDialog).toBeHidden();
  218 |     expect(net.filter((r) => r.url.includes("/api/v2/downloads/preview")).length, "取消后不得预览").toBe(0);
  219 |   });
  220 | 
  221 |   test("R9-04 混合文件：合法/非法/重复 → 服务端判定与最终 payload 只含 accepted", async ({ page }, testInfo) => {
  222 |     test.skip(!EMAIL || !PASSWORD || !ADDRESS, "creds not provided");
  223 |     test.skip(testInfo.project.name !== "uc-desktop", "desktop-only assertion set");
  224 |     const net: NetRecord[] = [];
  225 |     startCapture(page, net);
  226 |     await login(page);
  227 |     await openDownloadsNew(page);
  228 |     await page.locator("#download-chain").selectOption(CHAIN);
  229 |     await importFile(page, path.join(FIX, "mixed.xlsx"));
  230 | 
  231 |     const localDialog = dialog(page).filter({ hasText: "地址导入解析摘要（浏览器）" });
  232 |     await expect(localDialog).toBeVisible({ timeout: 30_000 });
  233 |     await page.getByRole("button", { name: "提交服务端校验" }).click();
  234 |     const serverDialog = dialog(page).filter({ hasText: "服务端地址校验结果" });
  235 |     await expect(serverDialog).toBeVisible({ timeout: 60_000 });
  236 |     const serverText = await serverDialog.innerText();
  237 |     const verdict = JSON.parse(net.filter((r) => r.url.includes("validate-addresses")).pop()?.responseBody ?? "{}");
  238 |     await page.screenshot({ path: path.join(OUT, testInfo.project.name, "06-mixed.png"), fullPage: false });
  239 |     await page.getByRole("button", { name: "使用服务端结果" }).click();
  240 | 
  241 |     await page.getByRole("button", { name: "Coverage 预览" }).click();
  242 |     const previewDialog = dialog(page).filter({ hasText: /无需新增 Provider 请求|Coverage 与成本预览完成|预览完成，存在风险提示/ });
  243 |     await expect(previewDialog).toBeVisible({ timeout: 60_000 });
  244 |     await previewDialog.getByRole("button", { name: "知道了" }).click();
  245 | 
  246 |     const previewCall = net.filter((r) => r.url.includes("/api/v2/downloads/preview")).pop();
  247 |     const previewBody = JSON.parse(previewCall?.requestBody ?? "{}");
  248 |     const codes = (verdict.rejected ?? []).map((r: { code: string }) => r.code).sort();
  249 |     dump(testInfo, "r9-04-evidence.json", {
  250 |       server_verdict_text: serverText, server_summary: verdict.summary,
  251 |       rejected_codes: codes, preview_request_body: previewBody,
  252 |     });
  253 |     expect(verdict.summary?.accepted, "混合文件只应有 1 条 accepted").toBe(1);
  254 |     expect(codes, "必须显式拒绝非法地址与重复地址").toEqual(["DUPLICATE_ADDRESS", "INVALID_ADDRESS"]);
  255 |     expect(previewBody.addresses, "最终 payload 只能包含服务端 accepted 的 normalized 地址").toEqual([ADDRESS.toLowerCase()]);
  256 |   });
  257 | 
  258 |   test("R9-05 重试不重复：同一幂等键 + 同一 payload 连续创建，必须复用同一任务", async ({ page }, testInfo) => {
  259 |     test.skip(!EMAIL || !PASSWORD || !ADDRESS, "creds not provided");
  260 |     test.skip(testInfo.project.name !== "uc-desktop", "desktop-only assertion set");
  261 |     await login(page);
  262 |     const payload = { chain: CHAIN, addresses: [ADDRESS.toLowerCase()], datasets: ["transactions"], range: { type: "full" }, reuse_policy: "prefer_local", performance_mode: "safe" };
  263 |     const key = "r9-retry-stable-key-0001";
  264 |     const headers = { ...(await authHeaders(page)), "Idempotency-Key": key };
  265 |     const first = await page.request.post("/api/v2/downloads", { data: payload, headers });
  266 |     const firstBody = await first.json().catch(() => ({}));
  267 |     const second = await page.request.post("/api/v2/downloads", { data: payload, headers });
  268 |     const secondBody = await second.json().catch(() => ({}));
  269 |     dump(testInfo, "r9-05-evidence.json", {
  270 |       first: { status: first.status(), body: firstBody }, second: { status: second.status(), body: secondBody }, payload, key,
  271 |     });
  272 |     expect(first.status(), "first create").toBeLessThan(300);
  273 |     expect(second.status(), "second create").toBeLessThan(300);
  274 |     expect(firstBody.job_id, "first create must return a job id").toBeTruthy();
```