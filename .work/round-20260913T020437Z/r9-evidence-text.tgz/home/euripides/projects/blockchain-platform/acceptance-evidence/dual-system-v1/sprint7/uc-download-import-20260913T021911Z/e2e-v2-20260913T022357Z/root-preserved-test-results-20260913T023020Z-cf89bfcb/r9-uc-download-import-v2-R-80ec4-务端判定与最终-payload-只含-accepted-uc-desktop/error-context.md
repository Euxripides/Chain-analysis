# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: r9-uc-download-import-v2.spec.ts >> R9 U-DL-01 CSV/XLSX import (app-v2) >> R9-04 混合文件：合法/非法/重复 → 服务端判定与最终 payload 只含 accepted
- Location: tests/r9-uc-download-import-v2.spec.ts:221:3

# Error details

```
Error: locator.click: Test ended.
Call log:
  - waiting for getByRole('button', { name: 'Coverage 预览' })

```

# Test source

```ts
  141 |     // 5) 断言真实请求体：只提交服务端 accepted 的 normalized 地址，且不带未解析元数据
  142 |     const previewCalls = net.filter((r) => r.url.includes("/api/v2/downloads/preview") && r.method === "POST");
  143 |     const createCalls = net.filter((r) => /\/api\/v2\/downloads$/.test(r.url) && r.method === "POST");
  144 |     expect(previewCalls.length, "必须真实调用过 preview").toBeGreaterThan(0);
  145 |     expect(createCalls.length, "必须真实调用过 create").toBe(1);
  146 |     const previewBody = JSON.parse(previewCalls[previewCalls.length - 1].requestBody ?? "{}");
  147 |     const createBody = JSON.parse(createCalls[0].requestBody ?? "{}");
  148 |     expect(previewBody.chain).toBe(CHAIN);
  149 |     expect(previewBody.addresses).toEqual([ADDRESS.toLowerCase()]);
  150 |     expect(Object.keys(previewBody.subject_meta ?? {}), "未解析的案件/标签不得出现在 payload 中").toEqual([]);
  151 |     expect(createBody.addresses).toEqual([ADDRESS.toLowerCase()]);
  152 |     expect(createBody.subject_meta ?? {}, "create 也不得携带未解析元数据").toEqual({});
  153 |     const createResponse = JSON.parse(createCalls[0].responseBody ?? "{}");
  154 |     dump(testInfo, "r9-01-evidence.json", {
  155 |       local_summary_text: localText, server_verdict_text: serverText, result_text: resultText,
  156 |       preview_request_body: previewBody, create_request_body: createBody, create_response: createResponse,
  157 |       preview_trace_ids: previewCalls.map((c) => ({ request_id: c.requestId, trace_id: c.traceId, status: c.status })),
  158 |       create_trace_ids: createCalls.map((c) => ({ request_id: c.requestId, trace_id: c.traceId, status: c.status })),
  159 |       all_api_calls: net.map((c) => ({ method: c.method, url: c.url, status: c.status, request_id: c.requestId, trace_id: c.traceId })),
  160 |     });
  161 |     expect(createCalls[0].status, "create 必须 200/201/202").toBeLessThan(300);
  162 |   });
  163 | 
  164 |   test("R9-02 坏文件：解析失败必须走 Dialog，且不得发出任何校验/创建请求", async ({ page }, testInfo) => {
  165 |     test.skip(!EMAIL || !PASSWORD || !ADDRESS, "creds not provided");
  166 |     test.skip(testInfo.project.name !== "uc-desktop", "desktop-only assertion set");
  167 |     const net: NetRecord[] = [];
  168 |     startCapture(page, net);
  169 |     await login(page);
  170 |     await openDownloadsNew(page);
  171 |     await importFile(page, path.join(FIX, "bad.xlsx"));
  172 | 
  173 |     const errDialog = dialog(page).filter({ hasText: "文件解析失败" });
  174 |     await expect(errDialog).toBeVisible({ timeout: 30_000 });
  175 |     const text = await errDialog.innerText();
  176 |     expect(text).toContain("bad.xlsx");
  177 |     await page.screenshot({ path: path.join(OUT, testInfo.project.name, "04-bad-file.png"), fullPage: false });
  178 |     await errDialog.getByRole("button", { name: "知道了" }).click();
  179 | 
  180 |     const validateCalls = net.filter((r) => r.url.includes("validate-addresses"));
  181 |     const createCalls = net.filter((r) => r.url.includes("/api/v2/downloads"));
  182 |     dump(testInfo, "r9-02-evidence.json", { dialog_text: text, validate_calls: validateCalls.length, create_calls: createCalls.length, all_api_calls: net.map((c) => ({ method: c.method, url: c.url, status: c.status })) });
  183 |     expect(validateCalls.length, "坏文件不得触发服务端校验").toBe(0);
  184 |     expect(createCalls.length, "坏文件不得触发创建").toBe(0);
  185 |   });
  186 | 
  187 |   test("R9-03 大文件 150 行：上限必须显式报出（接受 100 / 拒绝 50），取消后不得预览", async ({ page }, testInfo) => {
  188 |     test.skip(!EMAIL || !PASSWORD || !ADDRESS, "creds not provided");
  189 |     test.skip(testInfo.project.name !== "uc-desktop", "desktop-only assertion set");
  190 |     const net: NetRecord[] = [];
  191 |     startCapture(page, net);
  192 |     await login(page);
  193 |     await openDownloadsNew(page);
  194 |     await page.locator("#download-chain").selectOption(CHAIN);
  195 |     await importFile(page, path.join(FIX, "large.xlsx"));
  196 | 
  197 |     const localDialog = dialog(page).filter({ hasText: "地址导入解析摘要（浏览器）" });
  198 |     await expect(localDialog).toBeVisible({ timeout: 30_000 });
  199 |     const localText = await localDialog.innerText();
  200 |     expect(localText, "本地摘要必须报出超上限行数").toContain("超出单次上限");
  201 |     await page.getByRole("button", { name: "提交服务端校验" }).click();
  202 | 
  203 |     const serverDialog = dialog(page).filter({ hasText: "服务端地址校验结果" });
  204 |     await expect(serverDialog).toBeVisible({ timeout: 60_000 });
  205 |     const serverText = await serverDialog.innerText();
  206 |     await page.screenshot({ path: path.join(OUT, testInfo.project.name, "05-large-file.png"), fullPage: false });
  207 |     const validateCall = net.filter((r) => r.url.includes("validate-addresses")).pop();
  208 |     const verdict = JSON.parse(validateCall?.responseBody ?? "{}");
  209 |     dump(testInfo, "r9-03-evidence.json", {
  210 |       local_summary_text: localText, server_verdict_text: serverText,
  211 |       server_summary: verdict.summary, cap_rejected_sample: (verdict.rejected ?? []).slice(0, 3),
  212 |     });
  213 |     expect(verdict.summary?.accepted, "服务端必须恰好接受 100 条").toBe(100);
  214 |     expect(verdict.summary?.cap_rejected, "服务端必须显式拒绝其余 50 条").toBe(50);
  215 |     expect(serverText, "Dialog 必须显示被拒 50 条").toContain("服务端拒绝");
  216 |     await page.getByRole("button", { name: "取消" }).click();
  217 |     await expect(serverDialog).toBeHidden();
  218 |     expect(net.filter((r) => r.url.includes("/api/v2/downloads/preview")).length, "取消后不得预览").toBe(0);
  219 |   });
  220 | 
  221 |   test("R9-04 混合文件：合法/非法/重复 → 服务端判定与最终 payload 只含 accepted", async ({ page }, testInfo) => {
  222 |     test.skip(!EMAIL || !PASSWORD || !ADDRESS, "creds not provided");
  223 |     test.skip(testInfo.project.name !== "uc-desktop", "desktop-only assertion set");
  224 |     const net: NetRecord[] = [];
  225 |     startCapture(page, net);
  226 |     await login(page);
  227 |     await openDownloadsNew(page);
  228 |     await page.locator("#download-chain").selectOption(CHAIN);
  229 |     await importFile(page, path.join(FIX, "mixed.xlsx"));
  230 | 
  231 |     const localDialog = dialog(page).filter({ hasText: "地址导入解析摘要（浏览器）" });
  232 |     await expect(localDialog).toBeVisible({ timeout: 30_000 });
  233 |     await page.getByRole("button", { name: "提交服务端校验" }).click();
  234 |     const serverDialog = dialog(page).filter({ hasText: "服务端地址校验结果" });
  235 |     await expect(serverDialog).toBeVisible({ timeout: 60_000 });
  236 |     const serverText = await serverDialog.innerText();
  237 |     const verdict = JSON.parse(net.filter((r) => r.url.includes("validate-addresses")).pop()?.responseBody ?? "{}");
  238 |     await page.screenshot({ path: path.join(OUT, testInfo.project.name, "06-mixed.png"), fullPage: false });
  239 |     await page.getByRole("button", { name: "使用服务端结果" }).click();
  240 | 
> 241 |     await page.getByRole("button", { name: "Coverage 预览" }).click();
      |                                                             ^ Error: locator.click: Test ended.
  242 |     const previewDialog = dialog(page).filter({ hasText: /无需新增 Provider 请求|Coverage 与成本预览完成|预览完成，存在风险提示/ });
  243 |     await expect(previewDialog).toBeVisible({ timeout: 60_000 });
  244 |     await previewDialog.getByRole("button", { name: "知道了" }).click();
  245 | 
  246 |     const previewCall = net.filter((r) => r.url.includes("/api/v2/downloads/preview")).pop();
  247 |     const previewBody = JSON.parse(previewCall?.requestBody ?? "{}");
  248 |     const codes = (verdict.rejected ?? []).map((r: { code: string }) => r.code).sort();
  249 |     dump(testInfo, "r9-04-evidence.json", {
  250 |       server_verdict_text: serverText, server_summary: verdict.summary,
  251 |       rejected_codes: codes, preview_request_body: previewBody,
  252 |     });
  253 |     expect(verdict.summary?.accepted, "混合文件只应有 1 条 accepted").toBe(1);
  254 |     expect(codes, "必须显式拒绝非法地址与重复地址").toEqual(["DUPLICATE_ADDRESS", "INVALID_ADDRESS"]);
  255 |     expect(previewBody.addresses, "最终 payload 只能包含服务端 accepted 的 normalized 地址").toEqual([ADDRESS.toLowerCase()]);
  256 |   });
  257 | 
  258 |   test("R9-05 重试不重复：同一幂等键 + 同一 payload 连续创建，必须复用同一任务", async ({ page }, testInfo) => {
  259 |     test.skip(!EMAIL || !PASSWORD || !ADDRESS, "creds not provided");
  260 |     test.skip(testInfo.project.name !== "uc-desktop", "desktop-only assertion set");
  261 |     await login(page);
  262 |     const payload = { chain: CHAIN, addresses: [ADDRESS.toLowerCase()], datasets: ["transactions"], range: { type: "full" }, reuse_policy: "prefer_local", performance_mode: "safe" };
  263 |     const key = "r9-retry-stable-key-0001";
  264 |     const headers = { ...(await authHeaders(page)), "Idempotency-Key": key };
  265 |     const first = await page.request.post("/api/v2/downloads", { data: payload, headers });
  266 |     const firstBody = await first.json().catch(() => ({}));
  267 |     const second = await page.request.post("/api/v2/downloads", { data: payload, headers });
  268 |     const secondBody = await second.json().catch(() => ({}));
  269 |     dump(testInfo, "r9-05-evidence.json", {
  270 |       first: { status: first.status(), body: firstBody }, second: { status: second.status(), body: secondBody }, payload, key,
  271 |     });
  272 |     expect(first.status(), "first create").toBeLessThan(300);
  273 |     expect(second.status(), "second create").toBeLessThan(300);
  274 |     expect(firstBody.job_id, "first create must return a job id").toBeTruthy();
  275 |     expect(secondBody.job_id, "retry must reuse the same job, not create a new one").toBe(firstBody.job_id);
  276 |     const jobs = await page.request.get("/api/v2/jobs?limit=100", { headers: { "X-Auth-Audience": "user" } });
  277 |     const jobsBody = await jobs.json().catch(() => ({ items: [] }));
  278 |     const matching = (jobsBody.items ?? []).filter((j: { id: string }) => j.id === firstBody.job_id);
  279 |     expect(matching.length, "the reused job must exist exactly once in the job list").toBe(1);
  280 |   });
  281 | 
  282 |   test("R9-06 手机断点：导入 Dialog 在 390x844 可读且无横向溢出", async ({ page }, testInfo) => {
  283 |     test.skip(!EMAIL || !PASSWORD || !ADDRESS, "creds not provided");
  284 |     test.skip(testInfo.project.name !== "uc-mobile", "mobile-only assertion set");
  285 |     const net: NetRecord[] = [];
  286 |     startCapture(page, net);
  287 |     await login(page);
  288 |     await openDownloadsNew(page);
  289 |     const vp = page.viewportSize();
  290 |     const overflow = await page.evaluate(() => ({ scrollWidth: document.documentElement.scrollWidth, clientWidth: document.documentElement.clientWidth }));
  291 |     await importFile(page, path.join(FIX, "min.csv"));
  292 |     const localDialog = dialog(page).filter({ hasText: "地址导入解析摘要（浏览器）" });
  293 |     await expect(localDialog).toBeVisible({ timeout: 30_000 });
  294 |     const box = await localDialog.boundingBox();
  295 |     await page.screenshot({ path: path.join(OUT, testInfo.project.name, "07-mobile-import.png"), fullPage: true });
  296 |     await page.getByRole("button", { name: "提交服务端校验" }).click();
  297 |     const serverDialog = dialog(page).filter({ hasText: "服务端地址校验结果" });
  298 |     await expect(serverDialog).toBeVisible({ timeout: 60_000 });
  299 |     const serverBox = await serverDialog.boundingBox();
  300 |     await page.screenshot({ path: path.join(OUT, testInfo.project.name, "08-mobile-verdict.png"), fullPage: true });
  301 |     dump(testInfo, "r9-06-evidence.json", { viewport: vp, document_overflow: overflow, local_dialog_box: box, server_dialog_box: serverBox, api_calls: net.map((c) => ({ method: c.method, url: c.url, status: c.status })) });
  302 |     expect(vp?.width, "mobile project viewport").toBe(390);
  303 |     expect(overflow.scrollWidth, "page must not overflow horizontally at 390px").toBeLessThanOrEqual(overflow.clientWidth + 1);
  304 |     expect(box?.width ?? 0, "local dialog must fit the 390px viewport").toBeLessThanOrEqual(390);
  305 |     expect(serverBox?.width ?? 0, "server verdict dialog must fit the 390px viewport").toBeLessThanOrEqual(390);
  306 |   });
  307 | });
  308 | 
```