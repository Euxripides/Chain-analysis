# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: r9-uc-download-import-v2.spec.ts >> R9 U-DL-01 CSV/XLSX import (app-v2) >> R9-03 大文件 150 行：上限必须显式报出（接受 100 / 拒绝 50），取消后不得预览
- Location: tests/r9-uc-download-import-v2.spec.ts:187:3

# Error details

```
Error: 服务端必须恰好接受 100 条

expect(received).toBe(expected) // Object.is equality

Expected: 100
Received: undefined
```

# Page snapshot

```yaml
- generic [ref=f1e2]:
  - generic [ref=f1e3]:
    - navigation "主导航" [ref=f1e4]:
      - generic [ref=f1e5]:
        - generic [ref=f1e6]: CS
        - generic [ref=f1e7]:
          - generic [ref=f1e8]: ChainSight
          - text: 调查工作台 · user
      - generic [ref=f1e9]:
        - generic [ref=f1e10]: 工作台
        - link "我的概览" [ref=f1e11] [cursor=pointer]:
          - /url: /app-v2/home
        - link "全局搜索" [ref=f1e16] [cursor=pointer]:
          - /url: /app-v2/search
      - generic [ref=f1e21]:
        - generic [ref=f1e22]: 案件与调查
        - link "案件中心" [ref=f1e23] [cursor=pointer]:
          - /url: /app-v2/cases
        - link "调查任务" [ref=f1e27] [cursor=pointer]:
          - /url: /app-v2/investigations
        - link "资金图谱" [ref=f1e30] [cursor=pointer]:
          - /url: /app-v2/graph
      - generic [ref=f1e37]:
        - generic [ref=f1e38]: 数据工具
        - link "地址与交易查询" [ref=f1e39] [cursor=pointer]:
          - /url: /app-v2/explorer
        - link "数据下载" [ref=f1e44] [cursor=pointer]:
          - /url: /app-v2/downloads/new
        - link "任务中心" [ref=f1e49] [cursor=pointer]:
          - /url: /app-v2/jobs
        - link "导出中心" [ref=f1e54] [cursor=pointer]:
          - /url: /app-v2/exports
      - generic [ref=f1e59]:
        - generic [ref=f1e60]: 协作
        - link "待我处理" [ref=f1e61] [cursor=pointer]:
          - /url: /app-v2/inbox
        - link "报告中心" [ref=f1e66] [cursor=pointer]:
          - /url: /app-v2/reports
        - link "通知" [ref=f1e71] [cursor=pointer]:
          - /url: /app-v2/notifications
      - generic [ref=f1e76]:
        - generic [ref=f1e77]: 个人
        - link "个人资料与安全" [ref=f1e78] [cursor=pointer]:
          - /url: /app-v2/profile
      - button "收起导航" [ref=f1e83] [cursor=pointer]
    - generic [ref=f1e88]:
      - banner [ref=f1e89]:
        - button "打开主导航" [ref=f1e90] [cursor=pointer]
        - generic [ref=f1e92]: 用户层系统
        - generic [ref=f1e93]:
          - generic [ref=f1e97]: S
          - generic [ref=f1e98]:
            - generic [ref=f1e99]: S7 JobScope investigator
            - text: investigator
        - button "退出" [ref=f1e100] [cursor=pointer]
      - main [ref=f1e104]:
        - generic [ref=f1e105]:
          - heading "新建数据下载" [level=1] [ref=f1e107]
          - button "任务中心" [ref=f1e109] [cursor=pointer]
        - generic [ref=f1e110]:
          - generic [ref=f1e111]:
            - generic [ref=f1e112]:
              - heading "1 · 对象（地址）" [level=2] [ref=f1e114]
              - generic [ref=f1e116]:
                - generic [ref=f1e118]:
                  - generic [ref=f1e119]: 地址列表（已导入 0 个）
                  - textbox "地址列表（已导入 0 个）" [ref=f1e120]:
                    - /placeholder: 每行一个地址，或用逗号/分号/空白分隔后粘贴
                - generic [ref=f1e121]:
                  - button "解析导入" [ref=f1e122] [cursor=pointer]
                  - button "导入 CSV / XLSX" [ref=f1e123] [cursor=pointer]
                  - button "清空" [disabled] [ref=f1e124]
            - generic [ref=f1e125]:
              - heading "2 · 链与范围" [level=2] [ref=f1e127]
              - generic [ref=f1e129]:
                - generic [ref=f1e130]:
                  - generic [ref=f1e131]: 链
                  - combobox "链" [ref=f1e132]:
                    - option "请选择链"
                    - option "Arbitrum One（arbitrum）"
                    - option "Avalanche C-Chain（avalanche）"
                    - option "Base（base）"
                    - option "BNB Smart Chain（bsc）" [selected]
                    - option "Ethereum（eth）"
                    - option "OP Mainnet（optimism）"
                    - option "Polygon PoS（polygon）"
                    - option "TRON（tron）"
                - generic [ref=f1e133]:
                  - generic [ref=f1e134]: 范围类型
                  - combobox "范围类型" [ref=f1e135]:
                    - option "full · 全量" [selected]
                    - option "block · 区块区间"
                    - option "time · 时间区间"
                - generic [ref=f1e136]:
                  - generic [ref=f1e137]: 性能模式
                  - combobox "性能模式" [ref=f1e138]:
                    - option "safe" [selected]
                    - option "fast"
                    - option "turbo"
            - generic [ref=f1e139]:
              - heading "3 · Dataset" [level=2] [ref=f1e141]
              - group "Dataset 选择" [ref=f1e143]:
                - generic [ref=f1e144] [cursor=pointer]:
                  - checkbox "普通交易（transactions）" [checked] [ref=f1e145]
                  - text: 普通交易（transactions）
                - generic [ref=f1e146] [cursor=pointer]:
                  - checkbox "Token Transfer（token_transfers）" [checked] [ref=f1e147]
                  - text: Token Transfer（token_transfers）
                - generic [ref=f1e148] [cursor=pointer]:
                  - checkbox "NFT Transfer（nft_transfers）" [ref=f1e149]
                  - text: NFT Transfer（nft_transfers）
                - generic [ref=f1e150] [cursor=pointer]:
                  - checkbox "事件日志（logs）" [ref=f1e151]
                  - text: 事件日志（logs）
                - generic [ref=f1e152] [cursor=pointer]:
                  - checkbox "地址余额快照（balances）" [ref=f1e153]
                  - text: 地址余额快照（balances）
                - generic [ref=f1e154] [cursor=pointer]:
                  - checkbox "内部调用（internal_transactions）" [ref=f1e155]
                  - text: 内部调用（internal_transactions）
            - generic [ref=f1e156]:
              - heading "4 · 复用策略" [level=2] [ref=f1e158]
              - radiogroup "复用策略" [ref=f1e160]:
                - generic [ref=f1e161] [cursor=pointer]:
                  - radio "prefer_local（默认，优先复用本地）" [checked] [ref=f1e162]
                  - text: prefer_local（默认，优先复用本地）
                - generic [ref=f1e163] [cursor=pointer]:
                  - radio "refresh（不复用，新增 Provider 工作）" [ref=f1e164]
                  - text: refresh（不复用，新增 Provider 工作）
            - generic [ref=f1e165]:
              - generic [ref=f1e166]:
                - heading "5 · Coverage / 成本预览" [level=2] [ref=f1e167]
                - button "预览 Coverage 与成本" [ref=f1e169] [cursor=pointer]
              - generic [ref=f1e171]:
                - generic [ref=f1e175]: 尚未预览
                - button "立即预览" [ref=f1e176] [cursor=pointer]
            - generic [ref=f1e177]:
              - button "取消" [ref=f1e178] [cursor=pointer]
              - button "创建下载任务" [ref=f1e179] [cursor=pointer]
          - complementary "预览来源与复用" [ref=f1e180]:
            - heading "预览来源与复用" [level=2] [ref=f1e182]
            - generic [ref=f1e183]:
              - generic [ref=f1e184]:
                - generic [ref=f1e185]: 复用策略
                - generic [ref=f1e186]: prefer_local
              - generic [ref=f1e187]:
                - generic [ref=f1e188]: Coverage 命中
                - generic [ref=f1e189]: —
              - generic [ref=f1e190]:
                - generic [ref=f1e191]: 将复用
                - generic [ref=f1e192]: —
              - generic [ref=f1e193]:
                - generic [ref=f1e194]: 候选任务
                - generic [ref=f1e195]: —
              - generic [ref=f1e196]:
                - generic [ref=f1e197]: refresh
                - generic [ref=f1e198]: —
              - generic [ref=f1e199]:
                - generic [ref=f1e200]: 估算依据
                - generic [ref=f1e201]: —
              - generic [ref=f1e202]:
                - generic [ref=f1e203]: Coverage 来源
                - generic [ref=f1e204]: —
              - generic [ref=f1e205]:
                - generic [ref=f1e206]: Provider 来源
                - generic [ref=f1e207]: —
              - generic [ref=f1e208]:
                - generic [ref=f1e209]: 数据时点
                - generic [ref=f1e210]: —
              - generic [ref=f1e211]:
                - generic [ref=f1e212]: 最近 Trace
                - generic [ref=f1e213]: —
  - dialog [ref=f1e214]:
    - generic [ref=f1e215]:
      - generic [ref=f1e216]: 已完成
      - heading "服务端地址校验结果" [level=2] [ref=f1e217]
      - button "关闭对话框" [active] [ref=f1e218] [cursor=pointer]
    - generic [ref=f1e222]:
      - generic [ref=f1e223]: 只有服务端 accepted 的规范化地址会进入预览与创建；被拒条目不会静默丢弃。
      - generic [ref=f1e224]:
        - term [ref=f1e225]: 服务端提交
        - definition [ref=f1e226]: "100"
        - term [ref=f1e227]: 服务端接受
        - definition [ref=f1e228]: "100"
        - term [ref=f1e229]: 服务端拒绝
        - definition [ref=f1e230]: "0"
        - term [ref=f1e231]: 链分布
        - definition [ref=f1e232]: bsc:100
        - term [ref=f1e233]: 作用域
        - definition [ref=f1e234]: org 5edc0f75… / ws 8b41836b…
        - term [ref=f1e235]: 校验来源
        - definition [ref=f1e236]: server:dataset.NormalizeAndDedupeAddressesForChain + chain_registry + workspace-scoped meta lookup
        - term [ref=f1e237]: 本次会话权限
        - definition [ref=f1e238]: download:create=true · case:create=true · case:update=true
    - generic [ref=f1e239]:
      - button "取消" [ref=f1e240] [cursor=pointer]
      - button "使用服务端结果" [ref=f1e241] [cursor=pointer]
```

# Test source

```ts
  113 |     const serverDialog = dialog(page).filter({ hasText: "服务端地址校验结果" });
  114 |     await expect(serverDialog).toBeVisible({ timeout: 30_000 });
  115 |     const serverText = await serverDialog.innerText();
  116 |     expect(serverText, "服务端必须返回接受/拒绝计数").toContain("服务端接受");
  117 |     expect(serverText, "不存在的案件必须被明确标注为已移除，而不是只写不发生绑定").toContain("已从本次提交中移除");
  118 |     expect(serverText, "必须列出不存在的案件名").toContain(MISSING_CASE);
  119 |     expect(serverText, "必须列出不存在的标签名").toContain(MISSING_TAG);
  120 |     expect(serverText, "必须说明名称已从 payload 中移除").toContain("已从创建请求的 payload 中移除");
  121 |     await page.screenshot({ path: path.join(OUT, testInfo.project.name, "01-server-verdict.png"), fullPage: false });
  122 |     await page.getByRole("button", { name: "使用服务端结果" }).click();
  123 | 
  124 |     // 3) 预览（真实服务端 Coverage）
  125 |     await page.getByRole("button", { name: "Coverage 预览" }).click();
  126 |     const previewDialog = dialog(page).filter({ hasText: /无需新增 Provider 请求|Coverage 与成本预览完成|预览完成，存在风险提示/ });
  127 |     await expect(previewDialog).toBeVisible({ timeout: 60_000 });
  128 |     await page.screenshot({ path: path.join(OUT, testInfo.project.name, "02-preview.png"), fullPage: false });
  129 |     await previewDialog.getByRole("button", { name: "知道了" }).click();
  130 | 
  131 |     // 4) 真实创建
  132 |     await page.getByRole("button", { name: /创建下载任务|正在创建/ }).click();
  133 |     const confirmDialog = dialog(page).filter({ hasText: "确认创建下载任务？" });
  134 |     await expect(confirmDialog).toBeVisible({ timeout: 30_000 });
  135 |     await page.getByRole("button", { name: "确认创建" }).click();
  136 |     const resultDialog = dialog(page).filter({ hasText: /下载任务已创建|已复用现有任务|本地数据已覆盖|部分创建成功/ });
  137 |     await expect(resultDialog).toBeVisible({ timeout: 90_000 });
  138 |     const resultText = await resultDialog.innerText();
  139 |     await page.screenshot({ path: path.join(OUT, testInfo.project.name, "03-created.png"), fullPage: false });
  140 | 
  141 |     // 5) 断言真实请求体：只提交服务端 accepted 的 normalized 地址，且不带未解析元数据
  142 |     const previewCalls = net.filter((r) => r.url.includes("/api/v2/downloads/preview") && r.method === "POST");
  143 |     const createCalls = net.filter((r) => /\/api\/v2\/downloads$/.test(r.url) && r.method === "POST");
  144 |     expect(previewCalls.length, "必须真实调用过 preview").toBeGreaterThan(0);
  145 |     expect(createCalls.length, "必须真实调用过 create").toBe(1);
  146 |     const previewBody = JSON.parse(previewCalls[previewCalls.length - 1].requestBody ?? "{}");
  147 |     const createBody = JSON.parse(createCalls[0].requestBody ?? "{}");
  148 |     expect(previewBody.chain).toBe(CHAIN);
  149 |     expect(previewBody.addresses).toEqual([ADDRESS.toLowerCase()]);
  150 |     expect(Object.keys(previewBody.subject_meta ?? {}), "未解析的案件/标签不得出现在 payload 中").toEqual([]);
  151 |     expect(createBody.addresses).toEqual([ADDRESS.toLowerCase()]);
  152 |     expect(createBody.subject_meta ?? {}, "create 也不得携带未解析元数据").toEqual({});
  153 |     const createResponse = JSON.parse(createCalls[0].responseBody ?? "{}");
  154 |     dump(testInfo, "r9-01-evidence.json", {
  155 |       local_summary_text: localText, server_verdict_text: serverText, result_text: resultText,
  156 |       preview_request_body: previewBody, create_request_body: createBody, create_response: createResponse,
  157 |       preview_trace_ids: previewCalls.map((c) => ({ request_id: c.requestId, trace_id: c.traceId, status: c.status })),
  158 |       create_trace_ids: createCalls.map((c) => ({ request_id: c.requestId, trace_id: c.traceId, status: c.status })),
  159 |       all_api_calls: net.map((c) => ({ method: c.method, url: c.url, status: c.status, request_id: c.requestId, trace_id: c.traceId })),
  160 |     });
  161 |     expect(createCalls[0].status, "create 必须 200/201/202").toBeLessThan(300);
  162 |   });
  163 | 
  164 |   test("R9-02 坏文件：解析失败必须走 Dialog，且不得发出任何校验/创建请求", async ({ page }, testInfo) => {
  165 |     test.skip(!EMAIL || !PASSWORD || !ADDRESS, "creds not provided");
  166 |     test.skip(testInfo.project.name !== "uc-desktop", "desktop-only assertion set");
  167 |     const net: NetRecord[] = [];
  168 |     startCapture(page, net);
  169 |     await login(page);
  170 |     await openDownloadsNew(page);
  171 |     await importFile(page, path.join(FIX, "bad.xlsx"));
  172 | 
  173 |     const errDialog = dialog(page).filter({ hasText: "文件解析失败" });
  174 |     await expect(errDialog).toBeVisible({ timeout: 30_000 });
  175 |     const text = await errDialog.innerText();
  176 |     expect(text).toContain("bad.xlsx");
  177 |     await page.screenshot({ path: path.join(OUT, testInfo.project.name, "04-bad-file.png"), fullPage: false });
  178 |     await errDialog.getByRole("button", { name: "知道了" }).click();
  179 | 
  180 |     const validateCalls = net.filter((r) => r.url.includes("validate-addresses"));
  181 |     const createCalls = net.filter((r) => r.url.includes("/api/v2/downloads"));
  182 |     dump(testInfo, "r9-02-evidence.json", { dialog_text: text, validate_calls: validateCalls.length, create_calls: createCalls.length, all_api_calls: net.map((c) => ({ method: c.method, url: c.url, status: c.status })) });
  183 |     expect(validateCalls.length, "坏文件不得触发服务端校验").toBe(0);
  184 |     expect(createCalls.length, "坏文件不得触发创建").toBe(0);
  185 |   });
  186 | 
  187 |   test("R9-03 大文件 150 行：上限必须显式报出（接受 100 / 拒绝 50），取消后不得预览", async ({ page }, testInfo) => {
  188 |     test.skip(!EMAIL || !PASSWORD || !ADDRESS, "creds not provided");
  189 |     test.skip(testInfo.project.name !== "uc-desktop", "desktop-only assertion set");
  190 |     const net: NetRecord[] = [];
  191 |     startCapture(page, net);
  192 |     await login(page);
  193 |     await openDownloadsNew(page);
  194 |     await page.locator("#download-chain").selectOption(CHAIN);
  195 |     await importFile(page, path.join(FIX, "large.xlsx"));
  196 | 
  197 |     const localDialog = dialog(page).filter({ hasText: "地址导入解析摘要（浏览器）" });
  198 |     await expect(localDialog).toBeVisible({ timeout: 30_000 });
  199 |     const localText = await localDialog.innerText();
  200 |     expect(localText, "本地摘要必须报出超上限行数").toContain("超出单次上限");
  201 |     await page.getByRole("button", { name: "提交服务端校验" }).click();
  202 | 
  203 |     const serverDialog = dialog(page).filter({ hasText: "服务端地址校验结果" });
  204 |     await expect(serverDialog).toBeVisible({ timeout: 60_000 });
  205 |     const serverText = await serverDialog.innerText();
  206 |     await page.screenshot({ path: path.join(OUT, testInfo.project.name, "05-large-file.png"), fullPage: false });
  207 |     const validateCall = net.filter((r) => r.url.includes("validate-addresses")).pop();
  208 |     const verdict = JSON.parse(validateCall?.responseBody ?? "{}");
  209 |     dump(testInfo, "r9-03-evidence.json", {
  210 |       local_summary_text: localText, server_verdict_text: serverText,
  211 |       server_summary: verdict.summary, cap_rejected_sample: (verdict.rejected ?? []).slice(0, 3),
  212 |     });
> 213 |     expect(verdict.summary?.accepted, "服务端必须恰好接受 100 条").toBe(100);
      |                                                          ^ Error: 服务端必须恰好接受 100 条
  214 |     expect(verdict.summary?.cap_rejected, "服务端必须显式拒绝其余 50 条").toBe(50);
  215 |     expect(serverText, "Dialog 必须显示被拒 50 条").toContain("服务端拒绝");
  216 |     await page.getByRole("button", { name: "取消" }).click();
  217 |     await expect(serverDialog).toBeHidden();
  218 |     expect(net.filter((r) => r.url.includes("/api/v2/downloads/preview")).length, "取消后不得预览").toBe(0);
  219 |   });
  220 | 
  221 |   test("R9-04 混合文件：合法/非法/重复 → 服务端判定与最终 payload 只含 accepted", async ({ page }, testInfo) => {
  222 |     test.skip(!EMAIL || !PASSWORD || !ADDRESS, "creds not provided");
  223 |     test.skip(testInfo.project.name !== "uc-desktop", "desktop-only assertion set");
  224 |     const net: NetRecord[] = [];
  225 |     startCapture(page, net);
  226 |     await login(page);
  227 |     await openDownloadsNew(page);
  228 |     await page.locator("#download-chain").selectOption(CHAIN);
  229 |     await importFile(page, path.join(FIX, "mixed.xlsx"));
  230 | 
  231 |     const localDialog = dialog(page).filter({ hasText: "地址导入解析摘要（浏览器）" });
  232 |     await expect(localDialog).toBeVisible({ timeout: 30_000 });
  233 |     await page.getByRole("button", { name: "提交服务端校验" }).click();
  234 |     const serverDialog = dialog(page).filter({ hasText: "服务端地址校验结果" });
  235 |     await expect(serverDialog).toBeVisible({ timeout: 60_000 });
  236 |     const serverText = await serverDialog.innerText();
  237 |     const verdict = JSON.parse(net.filter((r) => r.url.includes("validate-addresses")).pop()?.responseBody ?? "{}");
  238 |     await page.screenshot({ path: path.join(OUT, testInfo.project.name, "06-mixed.png"), fullPage: false });
  239 |     await page.getByRole("button", { name: "使用服务端结果" }).click();
  240 | 
  241 |     await page.getByRole("button", { name: "Coverage 预览" }).click();
  242 |     const previewDialog = dialog(page).filter({ hasText: /无需新增 Provider 请求|Coverage 与成本预览完成|预览完成，存在风险提示/ });
  243 |     await expect(previewDialog).toBeVisible({ timeout: 60_000 });
  244 |     await previewDialog.getByRole("button", { name: "知道了" }).click();
  245 | 
  246 |     const previewCall = net.filter((r) => r.url.includes("/api/v2/downloads/preview")).pop();
  247 |     const previewBody = JSON.parse(previewCall?.requestBody ?? "{}");
  248 |     const codes = (verdict.rejected ?? []).map((r: { code: string }) => r.code).sort();
  249 |     dump(testInfo, "r9-04-evidence.json", {
  250 |       server_verdict_text: serverText, server_summary: verdict.summary,
  251 |       rejected_codes: codes, preview_request_body: previewBody,
  252 |     });
  253 |     expect(verdict.summary?.accepted, "混合文件只应有 1 条 accepted").toBe(1);
  254 |     expect(codes, "必须显式拒绝非法地址与重复地址").toEqual(["DUPLICATE_ADDRESS", "INVALID_ADDRESS"]);
  255 |     expect(previewBody.addresses, "最终 payload 只能包含服务端 accepted 的 normalized 地址").toEqual([ADDRESS.toLowerCase()]);
  256 |   });
  257 | 
  258 |   test("R9-05 重试不重复：同一幂等键 + 同一 payload 连续创建，必须复用同一任务", async ({ page }, testInfo) => {
  259 |     test.skip(!EMAIL || !PASSWORD || !ADDRESS, "creds not provided");
  260 |     test.skip(testInfo.project.name !== "uc-desktop", "desktop-only assertion set");
  261 |     await login(page);
  262 |     const payload = { chain: CHAIN, addresses: [ADDRESS.toLowerCase()], datasets: ["transactions"], range: { type: "full" }, reuse_policy: "prefer_local", performance_mode: "safe" };
  263 |     const key = "r9-retry-stable-key-0001";
  264 |     const headers = { ...(await authHeaders(page)), "Idempotency-Key": key };
  265 |     const first = await page.request.post("/api/v2/downloads", { data: payload, headers });
  266 |     const firstBody = await first.json().catch(() => ({}));
  267 |     const second = await page.request.post("/api/v2/downloads", { data: payload, headers });
  268 |     const secondBody = await second.json().catch(() => ({}));
  269 |     dump(testInfo, "r9-05-evidence.json", {
  270 |       first: { status: first.status(), body: firstBody }, second: { status: second.status(), body: secondBody }, payload, key,
  271 |     });
  272 |     expect(first.status(), "first create").toBeLessThan(300);
  273 |     expect(second.status(), "second create").toBeLessThan(300);
  274 |     expect(firstBody.job_id, "first create must return a job id").toBeTruthy();
  275 |     expect(secondBody.job_id, "retry must reuse the same job, not create a new one").toBe(firstBody.job_id);
  276 |     const jobs = await page.request.get("/api/v2/jobs?limit=100", { headers: { "X-Auth-Audience": "user" } });
  277 |     const jobsBody = await jobs.json().catch(() => ({ items: [] }));
  278 |     const matching = (jobsBody.items ?? []).filter((j: { id: string }) => j.id === firstBody.job_id);
  279 |     expect(matching.length, "the reused job must exist exactly once in the job list").toBe(1);
  280 |   });
  281 | 
  282 |   test("R9-06 手机断点：导入 Dialog 在 390x844 可读且无横向溢出", async ({ page }, testInfo) => {
  283 |     test.skip(!EMAIL || !PASSWORD || !ADDRESS, "creds not provided");
  284 |     test.skip(testInfo.project.name !== "uc-mobile", "mobile-only assertion set");
  285 |     const net: NetRecord[] = [];
  286 |     startCapture(page, net);
  287 |     await login(page);
  288 |     await openDownloadsNew(page);
  289 |     const vp = page.viewportSize();
  290 |     const overflow = await page.evaluate(() => ({ scrollWidth: document.documentElement.scrollWidth, clientWidth: document.documentElement.clientWidth }));
  291 |     await importFile(page, path.join(FIX, "min.csv"));
  292 |     const localDialog = dialog(page).filter({ hasText: "地址导入解析摘要（浏览器）" });
  293 |     await expect(localDialog).toBeVisible({ timeout: 30_000 });
  294 |     const box = await localDialog.boundingBox();
  295 |     await page.screenshot({ path: path.join(OUT, testInfo.project.name, "07-mobile-import.png"), fullPage: true });
  296 |     await page.getByRole("button", { name: "提交服务端校验" }).click();
  297 |     const serverDialog = dialog(page).filter({ hasText: "服务端地址校验结果" });
  298 |     await expect(serverDialog).toBeVisible({ timeout: 60_000 });
  299 |     const serverBox = await serverDialog.boundingBox();
  300 |     await page.screenshot({ path: path.join(OUT, testInfo.project.name, "08-mobile-verdict.png"), fullPage: true });
  301 |     dump(testInfo, "r9-06-evidence.json", { viewport: vp, document_overflow: overflow, local_dialog_box: box, server_dialog_box: serverBox, api_calls: net.map((c) => ({ method: c.method, url: c.url, status: c.status })) });
  302 |     expect(vp?.width, "mobile project viewport").toBe(390);
  303 |     expect(overflow.scrollWidth, "page must not overflow horizontally at 390px").toBeLessThanOrEqual(overflow.clientWidth + 1);
  304 |     expect(box?.width ?? 0, "local dialog must fit the 390px viewport").toBeLessThanOrEqual(390);
  305 |     expect(serverBox?.width ?? 0, "server verdict dialog must fit the 390px viewport").toBeLessThanOrEqual(390);
  306 |   });
  307 | });
  308 | 
```